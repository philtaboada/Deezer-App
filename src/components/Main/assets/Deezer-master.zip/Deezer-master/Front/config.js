export const API_URL = "https://api.deezer.com/";
export const API_TRACKS = "https://www.deezer.com/fr/track/";