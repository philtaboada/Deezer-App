import React from 'react'
import { Text, View, StyleSheet } from 'react-native';
import Style from '../assets/style.js'

export class SearchScreen extends React.Component {
	render() {
		return(
			<View style={ Style.container }>
			<Text>SearchScreen</Text>
			</View>
			)
	}
}